gnu httptunnel cygwin binary, compiled for www.neophob.com.

gnu httptunnel: http://www.nocrew.org/software/httptunnel.html
